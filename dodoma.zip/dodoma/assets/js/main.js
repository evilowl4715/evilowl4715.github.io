$(document).ready(function(){
  $('.phone').mask('+7 (999) 999-99-99');
  // $('.date').mask('12.12.1111');
});
