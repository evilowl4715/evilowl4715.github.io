<?php

$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];

$to      = 'Sizova_o@mail.ru,  evilowl123@mail.ru';
$subject = "=?utf-8?B?".base64_encode("Записаться на консультацию")."?=";
$headers = "От: $name, $phone, $email";

$success = mail($to, $subject, $headers);
echo $success;
?>
