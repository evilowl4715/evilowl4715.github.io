<?php

$name = $_POST['name'];
$phone = $_POST['phone'];

$to      = 'Sizova_o@mail.ru,  evilowl123@mail.ru';
$subject = "=?utf-8?B?".base64_encode("Перезвоните мне")."?=";
$headers = "От: $name";

$success = mail($to, $subject, $headers, $phone);
echo $success;
?>
